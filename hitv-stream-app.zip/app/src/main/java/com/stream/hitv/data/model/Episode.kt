package com.stream.hitv.data.model

data class Episode(
    val episodeNumber: Int,
    val title: String,
    val videoUrl: String,
    val subtitleUrl: String? = null,
    val duration: String = "45m"
)