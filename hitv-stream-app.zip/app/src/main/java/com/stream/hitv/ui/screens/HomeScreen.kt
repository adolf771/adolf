package com.stream.hitv.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stream.hitv.data.repository.MediaRepository
import com.stream.hitv.ui.components.BannerCarousel
import com.stream.hitv.ui.components.MediaCard

@Composable
fun HomeScreen(onMediaClick: (String) -> Unit) {
    val items = MediaRepository.mediaList
    val banner = items.firstOrNull()
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        if (banner != null) {
            item { BannerCarousel(item = banner) { onMediaClick(banner.id) } }
        }
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text("الأكثر مشاهدة 🔥", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                items(items) { media -> MediaCard(item = media) { onMediaClick(media.id) } }
            }
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}