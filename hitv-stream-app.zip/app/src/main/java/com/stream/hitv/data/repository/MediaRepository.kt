package com.stream.hitv.data.repository

import com.stream.hitv.data.model.Episode
import com.stream.hitv.data.model.MediaItem

object MediaRepository {
    private val sampleEpisodes = listOf(
        Episode(1, "الحلقة 1 - البداية", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
        Episode(2, "الحلقة 2 - الصراع", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
        Episode(3, "الحلقة 3 - المواجهة", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4")
    )

    val mediaList = listOf(
        MediaItem("1", "Solo Hunter: Awakening", "في عالم مليء بالبوابات والوحوش، يستيقظ أضعف صياد بقوة خارقة.", "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&q=80", "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1000&q=80", 9.8, "2024", "أنمي (Anime)", sampleEpisodes),
        MediaItem("2", "The Seoul Mystery", "دراما كورية مشوقة تدور حول محقق يواجه أسراراً مدفونة في قلب سيول.", "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&q=80", "https://images.unsplash.com/photo-1514565131-fce0801e5785?w=1000&q=80", 9.4, "2023", "دراما كورية (K-Drama)", sampleEpisodes)
    )

    fun getMediaById(id: String): MediaItem? = mediaList.find { it.id == id }
}