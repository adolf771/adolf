package com.stream.hitv.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.stream.hitv.data.repository.MediaRepository
import com.stream.hitv.ui.theme.AccentRed
import com.stream.hitv.ui.theme.SurfaceDark

@Composable
fun DetailScreen(mediaId: String, onPlayEpisode: (String, Int) -> Unit) {
    val media = MediaRepository.getMediaById(mediaId) ?: return
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            AsyncImage(model = media.bannerUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(240.dp))
            Column(modifier = Modifier.padding(16.dp)) {
                Text(media.title, style = MaterialTheme.typography.headlineSmall)
                Spacer(modifier = Modifier.height(4.dp))
                Text("${media.releaseYear} • ${media.category} • ★ ${media.rating}", color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))
                Text(media.description, color = Color.LightGray)
                Spacer(modifier = Modifier.height(20.dp))
                Text("قائمة الحلقات", style = MaterialTheme.typography.titleMedium)
            }
        }
        items(media.episodes) { ep ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(8.dp)).background(SurfaceDark).clickable { onPlayEpisode(media.id, ep.episodeNumber) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(ep.title, style = MaterialTheme.typography.bodyLarge)
                Icon(Icons.Default.PlayCircleOutline, contentDescription = null, tint = AccentRed)
            }
        }
    }
}