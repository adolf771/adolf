package com.stream.hitv
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.stream.hitv.ui.navigation.AppNavigation
import com.stream.hitv.ui.theme.BackgroundDark
import com.stream.hitv.ui.theme.HiTVTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HiTVTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = BackgroundDark) {
                    AppNavigation()
                }
            }
        }
    }
}