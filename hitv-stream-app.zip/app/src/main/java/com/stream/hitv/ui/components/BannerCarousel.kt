package com.stream.hitv.ui.components
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.stream.hitv.data.model.MediaItem
import com.stream.hitv.ui.theme.AccentRed

@Composable
fun BannerCarousel(item: MediaItem, onClick: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().height(320.dp).clickable { onClick() }) {
        AsyncImage(model = item.bannerUrl, contentDescription = item.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF090A0C)), startY = 150f)))
        Column(modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text(item.title, style = MaterialTheme.typography.headlineMedium, color = Color.White)
            Spacer(modifier = Modifier.height(4.dp))
            Text("${item.releaseYear} • ${item.category} • ★ ${item.rating}", color = Color.LightGray)
            Spacer(modifier = Modifier.height(10.dp))
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = AccentRed), shape = RoundedCornerShape(8.dp)) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("شاهد الآن")
            }
        }
    }
}