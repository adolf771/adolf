package com.stream.hitv.ui.navigation
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.stream.hitv.ui.player.PlayerScreen
import com.stream.hitv.ui.screens.DetailScreen
import com.stream.hitv.ui.screens.HomeScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(onMediaClick = { id -> navController.navigate("detail/$id") })
        }
        composable(
            route = "detail/{mediaId}",
            arguments = listOf(navArgument("mediaId") { type = NavType.StringType })
        ) { backStack ->
            val id = backStack.arguments?.getString("mediaId") ?: ""
            DetailScreen(mediaId = id, onPlayEpisode = { mId, ep -> navController.navigate("player/$mId/$ep") })
        }
        composable(
            route = "player/{mediaId}/{episodeNum}",
            arguments = listOf(navArgument("mediaId") { type = NavType.StringType }, navArgument("episodeNum") { type = NavType.IntType })
        ) { backStack ->
            val mId = backStack.arguments?.getString("mediaId") ?: ""
            val epNum = backStack.arguments?.getInt("episodeNum") ?: 1
            PlayerScreen(mediaId = mId, episodeNum = epNum)
        }
    }
}