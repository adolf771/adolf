package com.stream.hitv.data.model

data class MediaItem(
    val id: String,
    val title: String,
    val description: String,
    val posterUrl: String,
    val bannerUrl: String,
    val rating: Double,
    val releaseYear: String,
    val category: String,
    val episodes: List<Episode>
)