package com.stream.hitv.ui.theme
import androidx.compose.ui.graphics.Color
val BackgroundDark = Color(0xFF090A0C)
val SurfaceDark = Color(0xFF13151B)
val AccentRed = Color(0xFFE50914)
val AccentGold = Color(0xFFFFC107)
val TextPrimary = Color(0xFFFFFFFF)